
/* A Bison parser, made by GNU Bison 2.4.1.  */

/* Skeleton implementation for Bison's Yacc-like parsers in C
   
      Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.
   
   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.
   
   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "2.4.1"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1

/* Using locations.  */
#define YYLSP_NEEDED 0



/* Copy the first part of user declarations.  */

/* Line 189 of yacc.c  */
#line 5 "src/huginnet.y"

#define _GNU_SOURCE

#include <assert.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "lists.h"
#include "parser.h"
#include "clique.h"
#include "variable.h"
#include "errorhandler.h"
#include "Graph.h"

/* The current input file (TODO: get rid of this global variable...) */
static FILE *nip_net_file = NULL;

/* Is there a hugin net file open? 0 if no, 1 if yes. 
 * NOTE: could "nip_net_file == NULL" be used for representing the same info? 
 */
static int nip_net_file_open = 0;

/* Global variables for relaying results:
 * Some of the results are returned via global variables and some 
 * as the semantic values of net language constructs. 
 * The functional paradigm would be more elegant... */
static int nip_node_position_x = 100;
static int nip_node_position_y = 100;
static int nip_node_size_x = 80;
static int nip_node_size_y = 60;

static doublelist nip_parsed_doubles = NULL;
static int        nip_data_size      = 0;

static stringlist nip_parsed_strings = NULL;
static char**     nip_statenames = NULL;
static int        nip_n_statenames = 0;

/* All the unrecognized MY_field = "value" pairs */
static stringpairlist nip_ignored_net_fields = NULL;
static stringpairlist nip_ignored_node_fields = NULL;
static stringpairlist nip_ignored_potential_fields = NULL;

static char*      nip_label;       /* node label contents */
static char*      nip_persistence; /* NIP_next contents   */

static variablelist nip_parsed_vars   = NULL;
static variablelist nip_parent_vars   = NULL;

static Graph* nip_graph = NULL;

static potentialList nip_parsed_potentials = NULL;

static interfaceList nip_interface_relations = NULL;

static clique* nip_cliques = NULL;
static int   nip_n_cliques = 0;

static int
yylex (void);

static void
yyerror (const char *s);  /* Called by yyparse on error */

static int parsed_vars_to_graph(variablelist vl, Graph* g);

static int parsed_potentials_to_jtree(potentialList potentials, 
				      clique* cliques, int ncliques);

static int interface_to_vars(interfaceList il, variablelist vl);

static void print_parsed_stuff(potentialList pl);


/* Opens an input file. Returns 0 if file was opened or if some file was
 * already open. Returns ERROR_GENERAL if an error occurred
 * opening the file.
 */
FILE *open_net_file(const char *filename);

/* Closes the current input file (if there is one).
 */
void close_net_file();

/* Gives you the list of variables after yylex() */
variablelist get_parsed_variables (void);

/* Gives you the array of cliques after yylex() */
int get_cliques (clique** clique_array_pointer);

/* Gives you the global parameters of the whole network 
 * (node size is the only mandatory field...) */
void get_parsed_node_size(int* x, int* y);


/* Line 189 of yacc.c  */
#line 170 "src/huginnet.tab.c"

/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* Enabling the token table.  */
#ifndef YYTOKEN_TABLE
# define YYTOKEN_TABLE 0
#endif


/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     token_net = 258,
     token_class = 259,
     token_node_size = 260,
     token_data = 261,
     token_utility = 262,
     token_decision = 263,
     token_discrete = 264,
     token_continuous = 265,
     token_node = 266,
     token_label = 267,
     token_position = 268,
     token_states = 269,
     token_persistence = 270,
     token_potential = 271,
     token_normal = 272,
     QUOTED_STRING = 273,
     UNQUOTED_STRING = 274,
     NUMBER = 275
   };
#endif



#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
{

/* Line 214 of yacc.c  */
#line 104 "src/huginnet.y"

  double numval;
  double *doublearray;
  char *name;
  char **stringarray;
  variable var;
  /* list of X to get rid of global variables? */



/* Line 214 of yacc.c  */
#line 237 "src/huginnet.tab.c"
} YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
#endif


/* Copy the second part of user declarations.  */


/* Line 264 of yacc.c  */
#line 249 "src/huginnet.tab.c"

#ifdef short
# undef short
#endif

#ifdef YYTYPE_UINT8
typedef YYTYPE_UINT8 yytype_uint8;
#else
typedef unsigned char yytype_uint8;
#endif

#ifdef YYTYPE_INT8
typedef YYTYPE_INT8 yytype_int8;
#elif (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
typedef signed char yytype_int8;
#else
typedef short int yytype_int8;
#endif

#ifdef YYTYPE_UINT16
typedef YYTYPE_UINT16 yytype_uint16;
#else
typedef unsigned short int yytype_uint16;
#endif

#ifdef YYTYPE_INT16
typedef YYTYPE_INT16 yytype_int16;
#else
typedef short int yytype_int16;
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif ! defined YYSIZE_T && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned int
# endif
#endif

#define YYSIZE_MAXIMUM ((YYSIZE_T) -1)

#ifndef YY_
# if YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(e) ((void) (e))
#else
# define YYUSE(e) /* empty */
#endif

/* Identity function, used to suppress warnings about constant conditions.  */
#ifndef lint
# define YYID(n) (n)
#else
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static int
YYID (int yyi)
#else
static int
YYID (yyi)
    int yyi;
#endif
{
  return yyi;
}
#endif

#if ! defined yyoverflow || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#     ifndef _STDLIB_H
#      define _STDLIB_H 1
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (YYID (0))
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined _STDLIB_H \
       && ! ((defined YYMALLOC || defined malloc) \
	     && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef _STDLIB_H
#    define _STDLIB_H 1
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* ! defined yyoverflow || YYERROR_VERBOSE */


#if (! defined yyoverflow \
     && (! defined __cplusplus \
	 || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yytype_int16 yyss_alloc;
  YYSTYPE yyvs_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (yytype_int16) + sizeof (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  YYSIZE_T yyi;				\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (YYID (0))
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)				\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack_alloc, Stack, yysize);			\
	Stack = &yyptr->Stack_alloc;					\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (YYID (0))

#endif

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  19
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   165

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  28
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  26
/* YYNRULES -- Number of rules.  */
#define YYNRULES  56
/* YYNRULES -- Number of states.  */
#define YYNSTATES  149

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   275

#define YYTRANSLATE(YYX)						\
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const yytype_uint8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
      25,    26,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,    24,
       2,    23,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,    21,    27,    22,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const yytype_uint8 yyprhs[] =
{
       0,     0,     3,     6,    10,    18,    19,    22,    23,    26,
      32,    39,    46,    52,    58,    59,    62,    65,    68,    71,
      74,    75,    78,    81,    84,    87,    90,    95,    96,    99,
     102,   107,   112,   119,   127,   135,   140,   150,   158,   165,
     174,   176,   177,   180,   182,   183,   186,   188,   189,   192,
     197,   199,   200,   203,   208,   210,   212
};

/* YYRHS -- A `-1'-separated list of the rules' RHS.  */
static const yytype_int8 yyrhs[] =
{
      29,     0,    -1,    30,    31,    -1,    35,    30,    31,    -1,
       4,    19,    21,    36,    30,    31,    22,    -1,    -1,    32,
      30,    -1,    -1,    43,    31,    -1,    11,    19,    21,    34,
      22,    -1,     9,    11,    19,    21,    34,    22,    -1,    10,
      11,    19,    21,    33,    22,    -1,     7,    19,    21,    33,
      22,    -1,     8,    19,    21,    33,    22,    -1,    -1,    42,
      33,    -1,    39,    33,    -1,    37,    33,    -1,    38,    33,
      -1,    40,    33,    -1,    -1,    42,    34,    -1,    39,    34,
      -1,    37,    34,    -1,    38,    34,    -1,    40,    34,    -1,
       3,    21,    36,    22,    -1,    -1,    41,    36,    -1,    42,
      36,    -1,    12,    23,    18,    24,    -1,    15,    23,    18,
      24,    -1,    14,    23,    25,    47,    26,    24,    -1,    13,
      23,    25,    20,    20,    26,    24,    -1,     5,    23,    25,
      20,    20,    26,    24,    -1,    19,    23,    52,    24,    -1,
      16,    25,    44,    27,    45,    26,    21,    53,    22,    -1,
      16,    25,    44,    26,    21,    53,    22,    -1,    16,    25,
      44,    26,    21,    22,    -1,    16,    25,    44,    27,    45,
      26,    21,    22,    -1,    19,    -1,    -1,    46,    45,    -1,
      19,    -1,    -1,    48,    47,    -1,    18,    -1,    -1,    50,
      49,    -1,    25,    49,    26,    49,    -1,    20,    -1,    -1,
      20,    51,    -1,    25,    51,    26,    51,    -1,    18,    -1,
      51,    -1,     6,    23,    25,    49,    26,    24,    -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const yytype_uint16 yyrline[] =
{
       0,   146,   146,   178,   210,   243,   244,   248,   249,   253,
     321,   390,   407,   424,   443,   444,   445,   446,   447,   448,
     452,   453,   454,   455,   456,   457,   461,   465,   466,   467,
     471,   475,   479,   499,   505,   511,   515,   580,   607,   622,
     674,   681,   682,   686,   702,   703,   707,   722,   723,   724,
     728,   744,   745,   746,   750,   751,   755
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || YYTOKEN_TABLE
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "\"net\"", "\"class\"", "\"node_size\"",
  "\"data\"", "\"utility\"", "\"decision\"", "\"discrete\"",
  "\"continuous\"", "\"node\"", "\"label\"", "\"position\"", "\"states\"",
  "\"NIP_next\"", "\"potential\"", "\"normal\"", "QUOTED_STRING",
  "UNQUOTED_STRING", "NUMBER", "'{'", "'}'", "'='", "';'", "'('", "')'",
  "'|'", "$accept", "input", "nodes", "potentials", "nodeDeclaration",
  "ignored_params", "node_params", "netDeclaration", "parameters",
  "labelDeclaration", "persistenceDeclaration", "statesDeclaration",
  "positionDeclaration", "nodeSizeDeclaration", "unknownDeclaration",
  "potentialDeclaration", "child", "symbols", "symbol", "strings",
  "string", "numbers", "num", "ignored_numbers", "value", "dataList", 0
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[YYLEX-NUM] -- Internal token number corresponding to
   token YYLEX-NUM.  */
static const yytype_uint16 yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   123,   125,    61,    59,    40,    41,   124
};
# endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_uint8 yyr1[] =
{
       0,    28,    29,    29,    29,    30,    30,    31,    31,    32,
      32,    32,    32,    32,    33,    33,    33,    33,    33,    33,
      34,    34,    34,    34,    34,    34,    35,    36,    36,    36,
      37,    38,    39,    40,    41,    42,    43,    43,    43,    43,
      44,    45,    45,    46,    47,    47,    48,    49,    49,    49,
      50,    51,    51,    51,    52,    52,    53
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const yytype_uint8 yyr2[] =
{
       0,     2,     2,     3,     7,     0,     2,     0,     2,     5,
       6,     6,     5,     5,     0,     2,     2,     2,     2,     2,
       0,     2,     2,     2,     2,     2,     4,     0,     2,     2,
       4,     4,     6,     7,     7,     4,     9,     7,     6,     8,
       1,     0,     2,     1,     0,     2,     1,     0,     2,     4,
       1,     0,     2,     4,     1,     1,     6
};

/* YYDEFACT[STATE-NAME] -- Default rule to reduce with in state
   STATE-NUM when YYTABLE doesn't specify something else to do.  Zero
   means the default is an error.  */
static const yytype_uint8 yydefact[] =
{
       5,     0,     0,     0,     0,     0,     0,     0,     0,     7,
       5,     5,    27,     0,     0,     0,     0,     0,     0,     1,
       0,     2,     7,     6,     7,     0,     0,     0,    27,    27,
      27,    14,    14,     0,     0,    20,     0,     8,     3,     0,
      51,    26,    28,    29,     5,     0,     0,     0,     0,     0,
      14,    14,    14,    14,    14,     0,    20,    14,     0,    20,
      20,    20,    20,    20,    40,     0,     0,    54,    51,    51,
      55,     0,     7,     0,     0,     0,     0,    12,    17,    18,
      16,    19,    15,    13,     0,     0,     9,    23,    24,    22,
      25,    21,     0,    41,     0,    52,     0,    35,     0,     0,
       0,    44,     0,    10,    11,     0,    43,     0,    41,     0,
      51,     4,    30,     0,    46,     0,    44,    31,     0,    38,
       0,     0,    42,     0,    53,     0,     0,    45,     0,    37,
       0,    34,     0,    32,    47,    39,     0,    33,    50,    47,
       0,    47,    36,     0,     0,    48,    47,    56,    49
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
      -1,     8,     9,    21,    10,    49,    58,    11,    27,    50,
      51,    52,    53,    28,    54,    22,    65,   107,   108,   115,
     116,   140,   141,    70,    71,   120
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -127
static const yytype_int16 yypact[] =
{
      77,   -14,    -9,    13,    24,    10,    47,    64,    14,    74,
     100,   100,    26,    70,    82,    84,    83,    93,    92,  -127,
      89,  -127,    74,  -127,    74,    94,    95,    97,    26,    26,
      26,    85,    85,    99,   101,    85,    96,  -127,  -127,    91,
      36,  -127,  -127,  -127,   100,    98,   102,   103,   104,   106,
      85,    85,    85,    85,    85,   107,    85,    85,   108,    85,
      85,    85,    85,    85,  -127,    42,   111,  -127,    35,    35,
    -127,   109,    74,   105,   110,   112,   114,  -127,  -127,  -127,
    -127,  -127,  -127,  -127,   116,   117,  -127,  -127,  -127,  -127,
    -127,  -127,   113,   121,   122,  -127,   115,  -127,   123,   119,
     124,   118,   125,  -127,  -127,    -3,  -127,   120,   121,   126,
      35,  -127,  -127,   127,  -127,   128,   118,  -127,   130,  -127,
     129,   134,  -127,   132,  -127,   131,   135,  -127,   133,  -127,
       2,  -127,   136,  -127,    81,  -127,   139,  -127,  -127,    81,
     137,    81,  -127,   138,   141,  -127,    81,  -127,  -127
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int8 yypgoto[] =
{
    -127,  -127,    -5,   -20,  -127,    25,    33,  -127,    12,   -34,
     -26,     3,    11,  -127,   -12,  -127,  -127,    16,  -127,    32,
    -127,  -126,  -127,   -57,  -127,    20
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If zero, do what YYDEFACT says.
   If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -1
static const yytype_uint8 yytable[] =
{
      29,    59,    37,   118,    38,    23,    24,    12,   118,    60,
      13,    95,    96,   143,    19,   145,    29,    29,    29,   119,
     148,    16,    59,    63,   135,    59,    59,    59,    59,    59,
      60,    25,    14,    60,    60,    60,    60,    60,    61,    72,
      42,    43,    44,    15,    63,    26,    62,    63,    63,    63,
      63,    63,    98,   124,    67,    68,    68,    55,    17,    61,
      69,    69,    61,    61,    61,    61,    61,    62,    92,    93,
      62,    62,    62,    62,    62,    78,    79,    80,    81,    82,
       1,     2,    85,    18,     3,     4,     5,     6,     7,    84,
      20,    30,    87,    88,    89,    90,    91,    45,    46,    47,
      48,   138,    33,    31,    26,    32,   139,     3,     4,     5,
       6,     7,    34,    35,    36,    64,    66,    39,    40,    41,
      56,    73,    57,    99,   122,    74,    75,    76,    77,    83,
      86,    94,   102,    97,   105,   100,   114,   101,   103,   104,
     106,   110,   109,   112,   113,   111,   121,   125,   127,   117,
     136,   129,   123,   128,   126,   130,   131,   132,   134,   133,
     137,   142,     0,   144,   146,   147
};

static const yytype_int16 yycheck[] =
{
      12,    35,    22,     6,    24,    10,    11,    21,     6,    35,
      19,    68,    69,   139,     0,   141,    28,    29,    30,    22,
     146,    11,    56,    35,    22,    59,    60,    61,    62,    63,
      56,     5,    19,    59,    60,    61,    62,    63,    35,    44,
      28,    29,    30,    19,    56,    19,    35,    59,    60,    61,
      62,    63,    72,   110,    18,    20,    20,    32,    11,    56,
      25,    25,    59,    60,    61,    62,    63,    56,    26,    27,
      59,    60,    61,    62,    63,    50,    51,    52,    53,    54,
       3,     4,    57,    19,     7,     8,     9,    10,    11,    56,
      16,    21,    59,    60,    61,    62,    63,    12,    13,    14,
      15,    20,    19,    21,    19,    21,    25,     7,     8,     9,
      10,    11,    19,    21,    25,    19,    25,    23,    23,    22,
      21,    23,    21,    18,   108,    23,    23,    23,    22,    22,
      22,    20,    18,    24,    21,    25,    18,    25,    22,    22,
      19,    26,    20,    24,    20,    22,    26,    20,   116,    24,
     130,    22,    26,    23,    26,    21,    24,    26,    25,    24,
      24,    22,    -1,    26,    26,    24
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const yytype_uint8 yystos[] =
{
       0,     3,     4,     7,     8,     9,    10,    11,    29,    30,
      32,    35,    21,    19,    19,    19,    11,    11,    19,     0,
      16,    31,    43,    30,    30,     5,    19,    36,    41,    42,
      21,    21,    21,    19,    19,    21,    25,    31,    31,    23,
      23,    22,    36,    36,    36,    12,    13,    14,    15,    33,
      37,    38,    39,    40,    42,    33,    21,    21,    34,    37,
      38,    39,    40,    42,    19,    44,    25,    18,    20,    25,
      51,    52,    30,    23,    23,    23,    23,    22,    33,    33,
      33,    33,    33,    22,    34,    33,    22,    34,    34,    34,
      34,    34,    26,    27,    20,    51,    51,    24,    31,    18,
      25,    25,    18,    22,    22,    21,    19,    45,    46,    20,
      26,    22,    24,    20,    18,    47,    48,    24,     6,    22,
      53,    26,    45,    26,    51,    20,    26,    47,    23,    22,
      21,    24,    26,    24,    25,    22,    53,    24,    20,    25,
      49,    50,    22,    49,    26,    49,    26,    24,    49
};

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		(-2)
#define YYEOF		0

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrorlab


/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */

#define YYFAIL		goto yyerrlab

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yytoken = YYTRANSLATE (yychar);				\
      YYPOPSTACK (1);						\
      goto yybackup;						\
    }								\
  else								\
    {								\
      yyerror (YY_("syntax error: cannot back up")); \
      YYERROR;							\
    }								\
while (YYID (0))


#define YYTERROR	1
#define YYERRCODE	256


/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#define YYRHSLOC(Rhs, K) ((Rhs)[K])
#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)				\
    do									\
      if (YYID (N))                                                    \
	{								\
	  (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;	\
	  (Current).first_column = YYRHSLOC (Rhs, 1).first_column;	\
	  (Current).last_line    = YYRHSLOC (Rhs, N).last_line;		\
	  (Current).last_column  = YYRHSLOC (Rhs, N).last_column;	\
	}								\
      else								\
	{								\
	  (Current).first_line   = (Current).last_line   =		\
	    YYRHSLOC (Rhs, 0).last_line;				\
	  (Current).first_column = (Current).last_column =		\
	    YYRHSLOC (Rhs, 0).last_column;				\
	}								\
    while (YYID (0))
#endif


/* YY_LOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

#ifndef YY_LOCATION_PRINT
# if YYLTYPE_IS_TRIVIAL
#  define YY_LOCATION_PRINT(File, Loc)			\
     fprintf (File, "%d.%d-%d.%d",			\
	      (Loc).first_line, (Loc).first_column,	\
	      (Loc).last_line,  (Loc).last_column)
# else
#  define YY_LOCATION_PRINT(File, Loc) ((void) 0)
# endif
#endif


/* YYLEX -- calling `yylex' with the right arguments.  */

#ifdef YYLEX_PARAM
# define YYLEX yylex (YYLEX_PARAM)
#else
# define YYLEX yylex ()
#endif

/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (YYID (0))

# define YY_SYMBOL_PRINT(Title, Type, Value, Location)			  \
do {									  \
  if (yydebug)								  \
    {									  \
      YYFPRINTF (stderr, "%s ", Title);					  \
      yy_symbol_print (stderr,						  \
		  Type, Value); \
      YYFPRINTF (stderr, "\n");						  \
    }									  \
} while (YYID (0))


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_value_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_value_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (!yyvaluep)
    return;
# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# else
  YYUSE (yyoutput);
# endif
  switch (yytype)
    {
      default:
	break;
    }
}


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (yytype < YYNTOKENS)
    YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);

  yy_symbol_value_print (yyoutput, yytype, yyvaluep);
  YYFPRINTF (yyoutput, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_stack_print (yytype_int16 *yybottom, yytype_int16 *yytop)
#else
static void
yy_stack_print (yybottom, yytop)
    yytype_int16 *yybottom;
    yytype_int16 *yytop;
#endif
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)				\
do {								\
  if (yydebug)							\
    yy_stack_print ((Bottom), (Top));				\
} while (YYID (0))


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_reduce_print (YYSTYPE *yyvsp, int yyrule)
#else
static void
yy_reduce_print (yyvsp, yyrule)
    YYSTYPE *yyvsp;
    int yyrule;
#endif
{
  int yynrhs = yyr2[yyrule];
  int yyi;
  unsigned long int yylno = yyrline[yyrule];
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu):\n",
	     yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr, yyrhs[yyprhs[yyrule] + yyi],
		       &(yyvsp[(yyi + 1) - (yynrhs)])
		       		       );
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug)				\
    yy_reduce_print (yyvsp, Rule); \
} while (YYID (0))

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif



#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined __GLIBC__ && defined _STRING_H
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static YYSIZE_T
yystrlen (const char *yystr)
#else
static YYSIZE_T
yystrlen (yystr)
    const char *yystr;
#endif
{
  YYSIZE_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static char *
yystpcpy (char *yydest, const char *yysrc)
#else
static char *
yystpcpy (yydest, yysrc)
    char *yydest;
    const char *yysrc;
#endif
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYSIZE_T yyn = 0;
      char const *yyp = yystr;

      for (;;)
	switch (*++yyp)
	  {
	  case '\'':
	  case ',':
	    goto do_not_strip_quotes;

	  case '\\':
	    if (*++yyp != '\\')
	      goto do_not_strip_quotes;
	    /* Fall through.  */
	  default:
	    if (yyres)
	      yyres[yyn] = *yyp;
	    yyn++;
	    break;

	  case '"':
	    if (yyres)
	      yyres[yyn] = '\0';
	    return yyn;
	  }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

/* Copy into YYRESULT an error message about the unexpected token
   YYCHAR while in state YYSTATE.  Return the number of bytes copied,
   including the terminating null byte.  If YYRESULT is null, do not
   copy anything; just return the number of bytes that would be
   copied.  As a special case, return 0 if an ordinary "syntax error"
   message will do.  Return YYSIZE_MAXIMUM if overflow occurs during
   size calculation.  */
static YYSIZE_T
yysyntax_error (char *yyresult, int yystate, int yychar)
{
  int yyn = yypact[yystate];

  if (! (YYPACT_NINF < yyn && yyn <= YYLAST))
    return 0;
  else
    {
      int yytype = YYTRANSLATE (yychar);
      YYSIZE_T yysize0 = yytnamerr (0, yytname[yytype]);
      YYSIZE_T yysize = yysize0;
      YYSIZE_T yysize1;
      int yysize_overflow = 0;
      enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
      char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
      int yyx;

# if 0
      /* This is so xgettext sees the translatable formats that are
	 constructed on the fly.  */
      YY_("syntax error, unexpected %s");
      YY_("syntax error, unexpected %s, expecting %s");
      YY_("syntax error, unexpected %s, expecting %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s");
# endif
      char *yyfmt;
      char const *yyf;
      static char const yyunexpected[] = "syntax error, unexpected %s";
      static char const yyexpecting[] = ", expecting %s";
      static char const yyor[] = " or %s";
      char yyformat[sizeof yyunexpected
		    + sizeof yyexpecting - 1
		    + ((YYERROR_VERBOSE_ARGS_MAXIMUM - 2)
		       * (sizeof yyor - 1))];
      char const *yyprefix = yyexpecting;

      /* Start YYX at -YYN if negative to avoid negative indexes in
	 YYCHECK.  */
      int yyxbegin = yyn < 0 ? -yyn : 0;

      /* Stay within bounds of both yycheck and yytname.  */
      int yychecklim = YYLAST - yyn + 1;
      int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
      int yycount = 1;

      yyarg[0] = yytname[yytype];
      yyfmt = yystpcpy (yyformat, yyunexpected);

      for (yyx = yyxbegin; yyx < yyxend; ++yyx)
	if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
	  {
	    if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
	      {
		yycount = 1;
		yysize = yysize0;
		yyformat[sizeof yyunexpected - 1] = '\0';
		break;
	      }
	    yyarg[yycount++] = yytname[yyx];
	    yysize1 = yysize + yytnamerr (0, yytname[yyx]);
	    yysize_overflow |= (yysize1 < yysize);
	    yysize = yysize1;
	    yyfmt = yystpcpy (yyfmt, yyprefix);
	    yyprefix = yyor;
	  }

      yyf = YY_(yyformat);
      yysize1 = yysize + yystrlen (yyf);
      yysize_overflow |= (yysize1 < yysize);
      yysize = yysize1;

      if (yysize_overflow)
	return YYSIZE_MAXIMUM;

      if (yyresult)
	{
	  /* Avoid sprintf, as that infringes on the user's name space.
	     Don't have undefined behavior even if the translation
	     produced a string with the wrong number of "%s"s.  */
	  char *yyp = yyresult;
	  int yyi = 0;
	  while ((*yyp = *yyf) != '\0')
	    {
	      if (*yyp == '%' && yyf[1] == 's' && yyi < yycount)
		{
		  yyp += yytnamerr (yyp, yyarg[yyi++]);
		  yyf += 2;
		}
	      else
		{
		  yyp++;
		  yyf++;
		}
	    }
	}
      return yysize;
    }
}
#endif /* YYERROR_VERBOSE */


/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep)
#else
static void
yydestruct (yymsg, yytype, yyvaluep)
    const char *yymsg;
    int yytype;
    YYSTYPE *yyvaluep;
#endif
{
  YYUSE (yyvaluep);

  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  switch (yytype)
    {

      default:
	break;
    }
}

/* Prevent warnings from -Wmissing-prototypes.  */
#ifdef YYPARSE_PARAM
#if defined __STDC__ || defined __cplusplus
int yyparse (void *YYPARSE_PARAM);
#else
int yyparse ();
#endif
#else /* ! YYPARSE_PARAM */
#if defined __STDC__ || defined __cplusplus
int yyparse (void);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */


/* The lookahead symbol.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;

/* Number of syntax errors so far.  */
int yynerrs;



/*-------------------------.
| yyparse or yypush_parse.  |
`-------------------------*/

#ifdef YYPARSE_PARAM
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void *YYPARSE_PARAM)
#else
int
yyparse (YYPARSE_PARAM)
    void *YYPARSE_PARAM;
#endif
#else /* ! YYPARSE_PARAM */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void)
#else
int
yyparse ()

#endif
#endif
{


    int yystate;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus;

    /* The stacks and their tools:
       `yyss': related to states.
       `yyvs': related to semantic values.

       Refer to the stacks thru separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* The state stack.  */
    yytype_int16 yyssa[YYINITDEPTH];
    yytype_int16 *yyss;
    yytype_int16 *yyssp;

    /* The semantic value stack.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs;
    YYSTYPE *yyvsp;

    YYSIZE_T yystacksize;

  int yyn;
  int yyresult;
  /* Lookahead token as an internal (translated) token number.  */
  int yytoken;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;

#if YYERROR_VERBOSE
  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYSIZE_T yymsg_alloc = sizeof yymsgbuf;
#endif

#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  yytoken = 0;
  yyss = yyssa;
  yyvs = yyvsa;
  yystacksize = YYINITDEPTH;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY; /* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */
  yyssp = yyss;
  yyvsp = yyvs;

  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack.  Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	yytype_int16 *yyss1 = yyss;

	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  This used to be a
	   conditional around just the two extra args, but that might
	   be undefined if yyoverflow is a macro.  */
	yyoverflow (YY_("memory exhausted"),
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),
		    &yystacksize);

	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
	goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
	yystacksize = YYMAXDEPTH;

      {
	yytype_int16 *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyexhaustedlab;
	YYSTACK_RELOCATE (yyss_alloc, yyss);
	YYSTACK_RELOCATE (yyvs_alloc, yyvs);
#  undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;

      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yyn == YYPACT_NINF)
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid lookahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yyn == 0 || yyn == YYTABLE_NINF)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the shifted token.  */
  yychar = YYEMPTY;

  yystate = yyn;
  *++yyvsp = yylval;

  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 2:

/* Line 1455 of yacc.c  */
#line 146 "src/huginnet.y"
    {
  if(parsed_vars_to_graph(nip_parsed_vars, nip_graph) != NO_ERROR){
    report_error(__FILE__, __LINE__, ERROR_GENERAL, 1);
    YYABORT;
  }

  if(interface_to_vars(nip_interface_relations, nip_parsed_vars) != NO_ERROR){
    yyerror("Invalid timeslice specification!\nCheck NIP_next declarations.");
    YYABORT;
  }
  free_interfaceList(nip_interface_relations);

  nip_n_cliques = find_cliques(nip_graph, &nip_cliques);
  free_graph(nip_graph); /* Get rid of the graph (?) */
  nip_graph = NULL;
  if(nip_n_cliques < 0){
    report_error(__FILE__, __LINE__, ERROR_GENERAL, 1);
    YYABORT;
  }

  if(parsed_potentials_to_jtree(nip_parsed_potentials, 
				nip_cliques, nip_n_cliques) != NO_ERROR){
    report_error(__FILE__, __LINE__, ERROR_GENERAL, 1);
    YYABORT;
  }
#ifdef DEBUG_BISON
  print_parsed_stuff(nip_parsed_potentials);
#endif
  free_potentialList(nip_parsed_potentials); /* frees potentials also */
;}
    break;

  case 3:

/* Line 1455 of yacc.c  */
#line 178 "src/huginnet.y"
    {
  if(parsed_vars_to_graph(nip_parsed_vars, nip_graph) != NO_ERROR){
    report_error(__FILE__, __LINE__, ERROR_GENERAL, 1);
    YYABORT;
  }

  if(interface_to_vars(nip_interface_relations, nip_parsed_vars) != NO_ERROR){
    yyerror("Invalid timeslice specification!\nCheck NIP_next declarations.");
    YYABORT;
  }
  free_interfaceList(nip_interface_relations);

  nip_n_cliques = find_cliques(nip_graph, &nip_cliques);
  free_graph(nip_graph); /* Get rid of the graph (?) */
  nip_graph = NULL;
  if(nip_n_cliques < 0){
    report_error(__FILE__, __LINE__, ERROR_GENERAL, 1);
    YYABORT;
  }

  if(parsed_potentials_to_jtree(nip_parsed_potentials, 
				nip_cliques, nip_n_cliques) != NO_ERROR){
    report_error(__FILE__, __LINE__, ERROR_GENERAL, 1);
    YYABORT;
  }
#ifdef DEBUG_BISON
  print_parsed_stuff(nip_parsed_potentials);
#endif
  free_potentialList(nip_parsed_potentials); /* frees potentials also */
;}
    break;

  case 4:

/* Line 1455 of yacc.c  */
#line 210 "src/huginnet.y"
    {
  free((yyvsp[(2) - (7)].name)); /* the classname is useless */
  if(parsed_vars_to_graph(nip_parsed_vars, nip_graph) != NO_ERROR){
    report_error(__FILE__, __LINE__, ERROR_GENERAL, 1);
    YYABORT;
  }

  if(interface_to_vars(nip_interface_relations, nip_parsed_vars) != NO_ERROR){
    yyerror("Invalid timeslice specification!\nCheck NIP_next declarations.");
    YYABORT;
  }
  free_interfaceList(nip_interface_relations);

  nip_n_cliques = find_cliques(nip_graph, &nip_cliques);
  free_graph(nip_graph); /* Get rid of the graph (?) */
  nip_graph = NULL;
  if(nip_n_cliques < 0){
    report_error(__FILE__, __LINE__, ERROR_GENERAL, 1);
    YYABORT;
  }

  if(parsed_potentials_to_jtree(nip_parsed_potentials, 
				nip_cliques, nip_n_cliques) != NO_ERROR){
    report_error(__FILE__, __LINE__, ERROR_GENERAL, 1);
    YYABORT;
  }
#ifdef DEBUG_BISON
  print_parsed_stuff(nip_parsed_potentials);
#endif
  free_potentialList(nip_parsed_potentials); /* frees potentials also */
;}
    break;

  case 5:

/* Line 1455 of yacc.c  */
#line 243 "src/huginnet.y"
    { nip_graph = new_graph(nip_parsed_vars->length); ;}
    break;

  case 6:

/* Line 1455 of yacc.c  */
#line 244 "src/huginnet.y"
    {/* a variable added */;}
    break;

  case 7:

/* Line 1455 of yacc.c  */
#line 248 "src/huginnet.y"
    {/* list of initialisation data ready */;}
    break;

  case 8:

/* Line 1455 of yacc.c  */
#line 249 "src/huginnet.y"
    {/* potential added */;}
    break;

  case 9:

/* Line 1455 of yacc.c  */
#line 253 "src/huginnet.y"
    {
  int i,retval;
  char *label = nip_label;
  char **states = nip_statenames;
  variable v = NULL;
  
  /* have to check that all the necessary fields were included */
  if(label == NULL)
    asprintf(&label, " "); /* default label is empty */

  if(states == NULL){
    free(label); nip_label = NULL;
    asprintf(&label, "NIP parser: The states field is missing (node %s)", (yyvsp[(2) - (5)].name));
    yyerror(label);
    report_error(__FILE__, __LINE__, ERROR_GENERAL, 1);
    free((yyvsp[(2) - (5)].name));
    free(label);
    free(nip_persistence); nip_persistence = NULL;
    YYABORT;
  }

  v = new_variable((yyvsp[(2) - (5)].name), label, states, nip_n_statenames);

  if(v == NULL){
    report_error(__FILE__, __LINE__, ERROR_GENERAL, 1);
    free((yyvsp[(2) - (5)].name));
    free(label); nip_label = NULL;
    free(nip_persistence); nip_persistence = NULL;
    for(i = 0; i < nip_n_statenames; i++)
      free(nip_statenames[i]);
    free(nip_statenames); nip_statenames = NULL; nip_n_statenames = 0;
    YYABORT;
  }
  /* set the parsed position values */
  set_position(v, nip_node_position_x, nip_node_position_y);
  nip_node_position_x = 100; nip_node_position_y = 100; /* reset */

  if(nip_parsed_vars == NULL)
    nip_parsed_vars = make_variablelist();
  append_variable(nip_parsed_vars, v);

  if(nip_persistence != NULL){
    
    if(nip_interface_relations == NULL)
      nip_interface_relations = make_interfaceList();
    retval = append_interface(nip_interface_relations, v, nip_persistence);

    if(retval != NO_ERROR){
      report_error(__FILE__, __LINE__, ERROR_GENERAL, 1);
      free((yyvsp[(2) - (5)].name));
      free(label); nip_label = NULL;
      free(nip_persistence); nip_persistence = NULL;
      for(i = 0; i < nip_n_statenames; i++)
	free(nip_statenames[i]);
      free(nip_statenames); nip_statenames = NULL; nip_n_statenames = 0;
      free_variable(v);
      YYABORT;
    }
  }

  free((yyvsp[(2) - (5)].name));
  free(label);
  for(i = 0; i < nip_n_statenames; i++)
    free(nip_statenames[i]);
  free(nip_statenames); nip_statenames = NULL; nip_n_statenames = 0;
  nip_persistence = NULL;
  (yyval.var) = v;;}
    break;

  case 10:

/* Line 1455 of yacc.c  */
#line 321 "src/huginnet.y"
    {
  int i,retval;
  char *label = nip_label;
  char **states = nip_statenames;
  variable v = NULL;
  
  /* have to check that all the necessary fields were included */
  if(label == NULL)
    asprintf(&label, " "); /* default label is empty */

  if(states == NULL){
    free(label);
    nip_label = NULL;
    asprintf(&label, "NIP parser: The states field is missing (node %s)", (yyvsp[(3) - (6)].name));
    yyerror(label);
    report_error(__FILE__, __LINE__, ERROR_GENERAL, 1);
    free((yyvsp[(3) - (6)].name));
    free(label);
    free(nip_persistence); nip_persistence = NULL;
    YYABORT;
  }

  v = new_variable((yyvsp[(3) - (6)].name), label, states, nip_n_statenames);

  if(v == NULL){
    report_error(__FILE__, __LINE__, ERROR_GENERAL, 1);
    free((yyvsp[(3) - (6)].name));
    free(label);
    nip_label = NULL;
    free(nip_persistence); nip_persistence = NULL;
    for(i = 0; i < nip_n_statenames; i++)
      free(nip_statenames[i]);
    free(nip_statenames); nip_statenames = NULL; nip_n_statenames = 0;
    YYABORT;
  }
  /* set the parsed position values */
  set_position(v, nip_node_position_x, nip_node_position_y);
  nip_node_position_x = 100; nip_node_position_y = 100; /* reset */

  if(nip_parsed_vars == NULL)
    nip_parsed_vars = make_variablelist();
  append_variable(nip_parsed_vars, v);

  if(nip_persistence != NULL){

    if(nip_interface_relations == NULL)
      nip_interface_relations = make_interfaceList();
    retval = append_interface(nip_interface_relations, v, nip_persistence);
    if(retval != NO_ERROR){
      report_error(__FILE__, __LINE__, ERROR_GENERAL, 1);
      free((yyvsp[(3) - (6)].name));
      free(label); nip_label = NULL;
      free(nip_persistence); nip_persistence = NULL;
      for(i = 0; i < nip_n_statenames; i++)
	free(nip_statenames[i]);
      free(nip_statenames); nip_statenames = NULL; nip_n_statenames = 0;
      free_variable(v);
      YYABORT;
    }
  }

  free((yyvsp[(3) - (6)].name));
  free(label);
  for(i = 0; i < nip_n_statenames; i++)
    free(nip_statenames[i]);
  free(nip_statenames); nip_statenames = NULL; nip_n_statenames = 0;
  nip_persistence = NULL;
  (yyval.var) = v;;}
    break;

  case 11:

/* Line 1455 of yacc.c  */
#line 390 "src/huginnet.y"
    { 
  int i;
  char *label = nip_label;
  free(label); nip_label = NULL;
  asprintf(&label, "NET parser: Continuous variables (node %s) %s", (yyvsp[(3) - (6)].name), 
	   "are not supported.");
  yyerror(label);
  report_error(__FILE__, __LINE__, ERROR_GENERAL, 1);
  free((yyvsp[(3) - (6)].name));
  free(label);
  free(nip_persistence); nip_persistence = NULL;
  for(i = 0; i < nip_n_statenames; i++)
    free(nip_statenames[i]);
  free(nip_statenames); nip_statenames = NULL; nip_n_statenames = 0;
  YYABORT;
  (yyval.var)=NULL;;}
    break;

  case 12:

/* Line 1455 of yacc.c  */
#line 407 "src/huginnet.y"
    { 
  int i;
  char *label = nip_label;
  free(label); nip_label = NULL;
  asprintf(&label, "NET parser: Utility nodes (node %s) %s", (yyvsp[(2) - (5)].name), 
	   "are not supported.");
  yyerror(label);
  report_error(__FILE__, __LINE__, ERROR_GENERAL, 1);
  free((yyvsp[(2) - (5)].name));
  free(label);
  free(nip_persistence); nip_persistence = NULL;
  for(i = 0; i < nip_n_statenames; i++)
    free(nip_statenames[i]);
  free(nip_statenames); nip_statenames = NULL; nip_n_statenames = 0;
  YYABORT;
  (yyval.var)=NULL;;}
    break;

  case 13:

/* Line 1455 of yacc.c  */
#line 424 "src/huginnet.y"
    { 
  int i;
  char *label = nip_label;

  free(label); nip_label = NULL;
  asprintf(&label, "NET parser: Decision nodes (node %s) %s", (yyvsp[(2) - (5)].name), 
	   "are not supported.");
  yyerror(label);
  report_error(__FILE__, __LINE__, ERROR_GENERAL, 1);
  free((yyvsp[(2) - (5)].name));
  free(label);
  free(nip_persistence); nip_persistence = NULL;
  for(i = 0; i < nip_n_statenames; i++)
    free(nip_statenames[i]);
  free(nip_statenames); nip_statenames = NULL; nip_n_statenames = 0;
  YYABORT;
  (yyval.var)=NULL;;}
    break;

  case 16:

/* Line 1455 of yacc.c  */
#line 445 "src/huginnet.y"
    { /*nip_statenames = $1;*/ ;}
    break;

  case 17:

/* Line 1455 of yacc.c  */
#line 446 "src/huginnet.y"
    { nip_label = (yyvsp[(1) - (2)].name); ;}
    break;

  case 18:

/* Line 1455 of yacc.c  */
#line 447 "src/huginnet.y"
    { nip_persistence = (yyvsp[(1) - (2)].name); ;}
    break;

  case 22:

/* Line 1455 of yacc.c  */
#line 454 "src/huginnet.y"
    { /*nip_statenames = $1;*/ ;}
    break;

  case 23:

/* Line 1455 of yacc.c  */
#line 455 "src/huginnet.y"
    { nip_label = (yyvsp[(1) - (2)].name); ;}
    break;

  case 24:

/* Line 1455 of yacc.c  */
#line 456 "src/huginnet.y"
    { nip_persistence = (yyvsp[(1) - (2)].name); ;}
    break;

  case 26:

/* Line 1455 of yacc.c  */
#line 461 "src/huginnet.y"
    { /* did enough already */ ;}
    break;

  case 28:

/* Line 1455 of yacc.c  */
#line 466 "src/huginnet.y"
    {;}
    break;

  case 29:

/* Line 1455 of yacc.c  */
#line 467 "src/huginnet.y"
    {;}
    break;

  case 30:

/* Line 1455 of yacc.c  */
#line 471 "src/huginnet.y"
    { (yyval.name) = (yyvsp[(3) - (4)].name); ;}
    break;

  case 31:

/* Line 1455 of yacc.c  */
#line 475 "src/huginnet.y"
    { (yyval.name) = (yyvsp[(3) - (4)].name); ;}
    break;

  case 32:

/* Line 1455 of yacc.c  */
#line 479 "src/huginnet.y"
    { 

  /* makes an array of strings out of the parsed list of strings */
  nip_statenames = list_to_string_array(nip_parsed_strings);
  nip_n_statenames = nip_parsed_strings->length;

  /* free the list (not the strings) */
  empty_stringlist(nip_parsed_strings);
  free(nip_parsed_strings); nip_parsed_strings = NULL;

  if(!nip_statenames){
    report_error(__FILE__, __LINE__, ERROR_GENERAL, 1);
    YYABORT;
  }

  (yyval.stringarray) = nip_statenames;
;}
    break;

  case 33:

/* Line 1455 of yacc.c  */
#line 499 "src/huginnet.y"
    {
  nip_node_position_x = abs((int)(yyvsp[(4) - (7)].numval)); 
  nip_node_position_y = abs((int)(yyvsp[(5) - (7)].numval));;}
    break;

  case 34:

/* Line 1455 of yacc.c  */
#line 505 "src/huginnet.y"
    {
  nip_node_size_x = abs((int)(yyvsp[(4) - (7)].numval)); 
  nip_node_size_y = abs((int)(yyvsp[(5) - (7)].numval));;}
    break;

  case 35:

/* Line 1455 of yacc.c  */
#line 511 "src/huginnet.y"
    { free((yyvsp[(1) - (4)].name)); ;}
    break;

  case 36:

/* Line 1455 of yacc.c  */
#line 515 "src/huginnet.y"
    { 
  /* fixed ? : parser segfaults if <symbols> is an empty list... */
  int i;
  int retval, size;
  int nparents = 0;
  variable *family = NULL;
  variable *parents = NULL;
  double *doubles = (yyvsp[(8) - (9)].doublearray);
  char* error = NULL;
  potential p = NULL;

  if(nip_parent_vars != NULL)
    nparents = nip_parent_vars->length;

  family = (variable*) calloc(nparents + 1, sizeof(variable));

  if(nip_parent_vars != NULL)
    parents = list_to_variable_array(nip_parent_vars);

  /* TODO: parser could survive even when "potential(A| )" happens... */
  if(!parents || !family){
    free(family);
    free(parents);
    free(doubles);
    YYABORT;
  }

#ifdef DEBUG_BISON
  printf("nip_symbols_parsed = %d\n", nparents);
#endif

  family[0] = (yyvsp[(3) - (9)].var);
  size = CARDINALITY(family[0]);
  for(i = 0; i < nparents; i++){
    family[i + 1] = parents[i];
    size = size * CARDINALITY(parents[i]);
  }
  /* check that nip_data_size >= product of variable cardinalities! */
  if(size > nip_data_size){
    /* too few elements in the specified potential */
    asprintf(&error, 
	     "NET parser: Not enough elements in potential( %s... )!", 
	     get_symbol(family[0]));
    yyerror(error);
    free(family);
    free(parents);
    free(doubles);
    YYABORT;
  }

  if(nip_parsed_potentials == NULL)
    nip_parsed_potentials = make_potentialList();

  p = create_potential(family, nparents + 1, doubles);
  normalise_cpd(p); /* useless? */
  retval = append_potential(nip_parsed_potentials, p, family[0], parents);

  free(doubles); /* the data was copied at create_potential */
  empty_variablelist(nip_parent_vars);
  free(family);
  if(retval != NO_ERROR){
    report_error(__FILE__, __LINE__, retval, 1);
    YYABORT;
  }
;}
    break;

  case 37:

/* Line 1455 of yacc.c  */
#line 580 "src/huginnet.y"
    {
  int retval;
  variable *family;
  double *doubles = (yyvsp[(6) - (7)].doublearray);
  char* error = NULL;
  potential p = NULL;
  if(CARDINALITY((yyvsp[(3) - (7)].var)) > nip_data_size){
    /* too few elements in the specified potential */
    asprintf(&error, 
	     "NET parser: Not enough elements in potential( %s )!", 
	     get_symbol((yyvsp[(3) - (7)].var)));
    yyerror(error);
    free(doubles);
    YYABORT;
  }
  family = &(yyvsp[(3) - (7)].var);
  if(nip_parsed_potentials == NULL)
    nip_parsed_potentials = make_potentialList();
  p = create_potential(family, 1, doubles);
  normalise_potential(p); /* <=> normalise_cpd(p) in this case */
  retval = append_potential(nip_parsed_potentials, p, family[0], NULL); 
  free(doubles); /* the data was copied at create_potential */
  if(retval != NO_ERROR){
    report_error(__FILE__, __LINE__, retval, 1);
    YYABORT;
  }
;}
    break;

  case 38:

/* Line 1455 of yacc.c  */
#line 607 "src/huginnet.y"
    {
  int retval;
  variable* family;
  family = &(yyvsp[(3) - (6)].var);

  if(nip_parsed_potentials == NULL)
    nip_parsed_potentials = make_potentialList();
  retval = append_potential(nip_parsed_potentials, 
			    create_potential(family, 1, NULL), 
			    family[0], NULL); 
  if(retval != NO_ERROR){
    report_error(__FILE__, __LINE__, ERROR_GENERAL, 1);
    YYABORT;
  }
;}
    break;

  case 39:

/* Line 1455 of yacc.c  */
#line 622 "src/huginnet.y"
    {
  /* fixed ? : parser segfaults if <symbols> is an empty list... */
  int i;
  int retval, size;
  int nparents = 0;
  variable *family = NULL;
  variable *parents = NULL;
  potential p = NULL;

  if(nip_parent_vars != NULL)
    nparents = nip_parent_vars->length;

  family = (variable*) calloc(nparents + 1, sizeof(variable));

  if(nip_parent_vars != NULL)
    parents = list_to_variable_array(nip_parent_vars);

  /* TODO: parser could survive even when "potential(A| )" happens... */
  if(!parents || !family){
    free(family);
    free(parents);
    YYABORT;
  }

#ifdef DEBUG_BISON
  printf("nip_symbols_parsed = %d\n", nparents);
#endif

  family[0] = (yyvsp[(3) - (8)].var);
  size = CARDINALITY(family[0]);
  for(i = 0; i < nparents; i++){
    family[i + 1] = parents[i];
    size = size * CARDINALITY(parents[i]);
  }

  if(nip_parsed_potentials == NULL)
    nip_parsed_potentials = make_potentialList();

  p = create_potential(family, nparents + 1, NULL);
  normalise_cpd(p); /* useless? */
  retval = append_potential(nip_parsed_potentials, p, family[0], parents);

  empty_variablelist(nip_parent_vars);
  free(family);
  if(retval != NO_ERROR){
    report_error(__FILE__, __LINE__, retval, 1);
    YYABORT;
  }
;}
    break;

  case 40:

/* Line 1455 of yacc.c  */
#line 674 "src/huginnet.y"
    { 
  (yyval.var) = get_parser_variable(nip_parsed_vars, (yyvsp[(1) - (1)].name));
  /* NOTE: you could check unrecognized child variables here */
  free((yyvsp[(1) - (1)].name)); ;}
    break;

  case 43:

/* Line 1455 of yacc.c  */
#line 686 "src/huginnet.y"
    { 
	       /* NOTE: inverted list takes care of the correct order... */
	       int retval;
	       if(nip_parent_vars == NULL)
		 nip_parent_vars = make_variablelist();
	       retval = prepend_variable(nip_parent_vars, 
			  get_parser_variable(nip_parsed_vars, (yyvsp[(1) - (1)].name)));
	       if(retval != NO_ERROR){
		 /* NOTE: you could check unrecognized parent variables here */
		 report_error(__FILE__, __LINE__, ERROR_GENERAL, 1);
		 YYABORT;
	       }
	       free((yyvsp[(1) - (1)].name)); ;}
    break;

  case 46:

/* Line 1455 of yacc.c  */
#line 707 "src/huginnet.y"
    {
	       int retval;

	       if(nip_parsed_strings == NULL)
		 nip_parsed_strings = make_stringlist();

	       retval = append_string(nip_parsed_strings, (yyvsp[(1) - (1)].name));
	       if(retval != NO_ERROR){
		 report_error(__FILE__, __LINE__, retval, 1);
		 YYABORT;
	       }
;}
    break;

  case 50:

/* Line 1455 of yacc.c  */
#line 728 "src/huginnet.y"
    {
	     int retval;

	     /* If the list is not created yet */
	     if(nip_parsed_doubles == NULL)
	       nip_parsed_doubles = make_doublelist();

	     retval = append_double(nip_parsed_doubles, (yyvsp[(1) - (1)].numval));
	     if(retval != NO_ERROR){
	       report_error(__FILE__, __LINE__, ERROR_GENERAL, 1);
	       YYABORT;
	     }
;}
    break;

  case 52:

/* Line 1455 of yacc.c  */
#line 745 "src/huginnet.y"
    {;}
    break;

  case 54:

/* Line 1455 of yacc.c  */
#line 750 "src/huginnet.y"
    { free((yyvsp[(1) - (1)].name)); ;}
    break;

  case 56:

/* Line 1455 of yacc.c  */
#line 755 "src/huginnet.y"
    {
  /* Note: this doesn't normalise them in any way */
  double *doubles = list_to_double_array(nip_parsed_doubles);
  nip_data_size = nip_parsed_doubles->length;
  empty_doublelist(nip_parsed_doubles); 
  free(nip_parsed_doubles); nip_parsed_doubles = NULL;
  if(!doubles){
    report_error(__FILE__, __LINE__, ERROR_GENERAL, 1);
    YYABORT;
  }
  (yyval.doublearray) = doubles;
;}
    break;



/* Line 1455 of yacc.c  */
#line 2312 "src/huginnet.tab.c"
      default: break;
    }
  YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;

  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if ! YYERROR_VERBOSE
      yyerror (YY_("syntax error"));
#else
      {
	YYSIZE_T yysize = yysyntax_error (0, yystate, yychar);
	if (yymsg_alloc < yysize && yymsg_alloc < YYSTACK_ALLOC_MAXIMUM)
	  {
	    YYSIZE_T yyalloc = 2 * yysize;
	    if (! (yysize <= yyalloc && yyalloc <= YYSTACK_ALLOC_MAXIMUM))
	      yyalloc = YYSTACK_ALLOC_MAXIMUM;
	    if (yymsg != yymsgbuf)
	      YYSTACK_FREE (yymsg);
	    yymsg = (char *) YYSTACK_ALLOC (yyalloc);
	    if (yymsg)
	      yymsg_alloc = yyalloc;
	    else
	      {
		yymsg = yymsgbuf;
		yymsg_alloc = sizeof yymsgbuf;
	      }
	  }

	if (0 < yysize && yysize <= yymsg_alloc)
	  {
	    (void) yysyntax_error (yymsg, yystate, yychar);
	    yyerror (yymsg);
	  }
	else
	  {
	    yyerror (YY_("syntax error"));
	    if (yysize != 0)
	      goto yyexhaustedlab;
	  }
      }
#endif
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
	 error, discard it.  */

      if (yychar <= YYEOF)
	{
	  /* Return failure if at end of input.  */
	  if (yychar == YYEOF)
	    YYABORT;
	}
      else
	{
	  yydestruct ("Error: discarding",
		      yytoken, &yylval);
	  yychar = YYEMPTY;
	}
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (/*CONSTCOND*/ 0)
     goto yyerrorlab;

  /* Do not reclaim the symbols of the rule which action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (yyn != YYPACT_NINF)
	{
	  yyn += YYTERROR;
	  if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
	    {
	      yyn = yytable[yyn];
	      if (0 < yyn)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
	YYABORT;


      yydestruct ("Error: popping",
		  yystos[yystate], yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  *++yyvsp = yylval;


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#if !defined(yyoverflow) || YYERROR_VERBOSE
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEMPTY)
     yydestruct ("Cleanup: discarding lookahead",
		 yytoken, &yylval);
  /* Do not reclaim the symbols of the rule which action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
		  yystos[*yyssp], yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
#if YYERROR_VERBOSE
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
#endif
  /* Make sure YYID is used.  */
  return YYID (yyresult);
}



/* Line 1675 of yacc.c  */
#line 769 "src/huginnet.y"

/* Lexical analyzer */
/*
 *      yylex is able to parse strings i.e. strings are terminals: 
 *      "this is a string": char* -> [t, h, i, s, ... , g, \0] as lvalue 
 */

#include <ctype.h>

static int
yylex (void)
{
  int tokenlength;
  int retval = 0;
  char *token = next_token(&tokenlength, nip_net_file);
  char *nullterminated;
  char *endptr;
  double numval;

  /* EOF or error */
  if(tokenlength <= 0)
    return 0;

  /* Single character */
  else if(tokenlength == 1){
    retval = *token;

    nullterminated = (char *) calloc(2, sizeof(char));
    if(!nullterminated){
      report_error(__FILE__, __LINE__, ERROR_OUTOFMEMORY, 1);
      free(token);
      return 0; /* In the case of an (unlikely) error, stop the parser */
    }
    nullterminated[0] = *token;
    nullterminated[1] = '\0';

    /* Single letter ('A' - 'Z' or 'a' - 'z') is UNQUOTED_STRING. */
    if(isalpha((int)*token)){
      yylval.name = nullterminated;
      free(token);

      return UNQUOTED_STRING;
    }

    /* Single digit ('0' - '9') is NUMBER. */
    else if(isdigit((int)*token)){
      yylval.numval = strtod(nullterminated, 0);
      free(token);
      free(nullterminated);
      return NUMBER;
    }

    /* Other chars (';' '(', ')', etc. ) */
    else {
      free(token);
      free(nullterminated);
      return retval;
    }
  }

  /* Multicharacter tokens */
  else{
    /* Literal string tokens */ 

    /* net */
    if(tokenlength == 3 && strncmp("net", token, 3) == 0){
      free(token);
      return token_net;
    }

    if(tokenlength == 4){
      /* node */
      if(strncmp("node", token, 4) == 0){
	free(token);
	return token_node;
      }
      /* data */
      else if(strncmp("data", token, 4) == 0){
	free(token);
	return token_data;
      }
    }

    if(tokenlength == 5){
      /* label */
      if(strncmp("label", token, 5) == 0){
	free(token);
	return token_label;
      }
      /* class */
      else if(strncmp("class", token, 5) == 0){
	free(token);
	return token_class;
      }
    }

    if(tokenlength == 6){
      /* states */
      if(strncmp("states", token, 6) == 0){
	free(token);
	return token_states;
      }
      /* normal */
      else if(strncmp("normal", token, 6) == 0){
	free(token);
	return token_normal;
      }
    }

    if(tokenlength == 7){
      /* utility */
      if(strncmp("utility", token, 7) == 0){
	free(token);
	return token_utility;
      }      
    }

    if(tokenlength == 8){
      /* position */
      if(strncmp("position", token, 8) == 0){
	free(token);
	return token_position;
      }
      /* decision */
      else if(strncmp("decision", token, 8) == 0){
	free(token);
	return token_decision;
      }
      /* discrete */
      else if(strncmp("discrete", token, 8) == 0){
	free(token);
	return token_discrete;
      }
      /* NIP_next */
      else if(strncmp("NIP_next", token, 8) == 0){
	free(token);
	return token_persistence;
      }
    }

    if(tokenlength == 9){ 
      /* node_size */
      if(strncmp("node_size", token, 9) == 0){
	free(token);
	return token_node_size;
      }
      /* potential */
      else if(strncmp("potential", token, 9) == 0){
	free(token);
	return token_potential;
      }
    }

    /* continuous */
    if(tokenlength == 10 &&
       strncmp("continuous", token, 10) == 0){
      free(token);
      return token_continuous;
    }

    /* End of literal string tokens */

    /* Regular tokens (not literal string) */
    /* QUOTED_STRING (enclosed in double quotes) */
    if(token[0] == '"' &&
       token[tokenlength - 1] == '"'){
      nullterminated = (char *) calloc(tokenlength - 1, sizeof(char));
      if(!nullterminated){
	report_error(__FILE__, __LINE__, ERROR_OUTOFMEMORY, 1);
	free(token);
	return 0; /* In the case of an (unlikely) error, stop the parser */
      }
      /* For the semantic value of the string, strip off double quotes
       * and insert terminating null character. */
      strncpy(nullterminated, &(token[1]), tokenlength - 2);
      nullterminated[tokenlength - 2] = '\0';
      yylval.name = nullterminated;

      free(token);

      return QUOTED_STRING;
    }

    nullterminated = (char *) calloc(tokenlength + 1, sizeof(char));
    if(!nullterminated){
      report_error(__FILE__, __LINE__, ERROR_OUTOFMEMORY, 1);
      free(token);
      return 0; /* In the case of an (unlikely) error, stop the parser */
    }
    strncpy(nullterminated, token, tokenlength);
    nullterminated[tokenlength] = '\0';

    /* NUMBER ? */
    numval = strtod(nullterminated, &endptr);
    /* No error, so the token is a valid double. */
    if(!(nullterminated == endptr && numval == 0)){
      yylval.numval = numval;
      free(token);
      free(nullterminated);
      return NUMBER;
    }

    /* Everything else is UNQUOTED_STRING */
    yylval.name = nullterminated;

    free(token);

    return UNQUOTED_STRING;

  }

}


static void
yyerror (const char *s)  /* Called by yyparse on error */
{
  printf ("%s\n", s);
}


/* Puts the variables into the graph */
static int parsed_vars_to_graph(variablelist vl, Graph* g){
  int i, retval;
  variable v;
  variable_iterator it;
  potentialLink initlist = nip_parsed_potentials->first;

  /*assert(vl != NULL);*/
  it = vl->first;
  v = next_variable(&it);
  
  /* Add parsed variables to the graph. */
  while(v != NULL){
    retval = add_variable(g, v);
    if(retval != NO_ERROR){
      report_error(__FILE__, __LINE__, ERROR_GENERAL, 1);
      return ERROR_GENERAL;
    }
    v = next_variable(&it);
  }

  /* Add child - parent relations to the graph. */
  while(initlist != NULL){  
    for(i = 0; i < initlist->data->num_of_vars - 1; i++){
      retval = add_child(g, initlist->parents[i], initlist->child);
      if(retval != NO_ERROR){

	if(g == NULL)
	  printf("DEBUG\n");

	assert(initlist->parents[i] != NULL); /* FAILS! */

	printf("Child:  %s\n", initlist->child->symbol);
	printf("Parent: %s\n", initlist->parents[i]->symbol);

	report_error(__FILE__, __LINE__, ERROR_GENERAL, 1);
	return ERROR_GENERAL;
      }
    }
    
    /* Add child - parent relations to variables themselves also */
    set_parents(initlist->child, initlist->parents, 
		initlist->data->num_of_vars - 1);

    initlist = initlist->fwd;
  }
  return NO_ERROR;
}


/* Initialises the join tree (clique array) with parsed potentials. 
 * NOTE: the priors of independent variables are not entered into the 
 * join tree (as evidence), but are stored into the variable though.
 * Returns an error code. (0 is O.K.) */
static int parsed_potentials_to_jtree(potentialList potentials, 
				      clique* cliques, int ncliques){
  int retval;
  potentialLink initlist = potentials->first;
  clique fam_clique = NULL;

  while(initlist != NULL){
    fam_clique = find_family(cliques, ncliques, initlist->child);

    if(fam_clique != NULL){
      if(initlist->data->num_of_vars > 1){
	/* Conditional probability distributions are initialised into
	 * the jointree potentials */
	retval = initialise(fam_clique, initlist->child, 
			    initlist->data, 0); /* THE job */
	if(retval != NO_ERROR){
	  report_error(__FILE__, __LINE__, ERROR_GENERAL, 1);
	  return ERROR_GENERAL;
	}
      }
      else{
	/* Priors of the independent variables are stored into the variable 
	 * itself, but NOT entered into the model YET. */
	/*retval = enter_evidence(vars, nvars, nip_cliques, 
	 *			nip_num_of_cliques, initlist->child, 
	 *			initlist->data->data); OLD STUFF */
	retval = set_prior(initlist->child, initlist->data->data);
	if(retval != NO_ERROR){
	  report_error(__FILE__, __LINE__, ERROR_GENERAL, 1);
	  return ERROR_GENERAL;
	}
      }
    }
    else
      fprintf(stderr, "In %s (%d): find_family failed!\n", __FILE__, __LINE__);
    initlist = initlist->fwd;
  }
  return NO_ERROR;
}


static int interface_to_vars(interfaceList il, variablelist vl){
  int i, m;
  variable v1, v2;
  interfaceLink initlist = NULL;
  variable_iterator it = NULL;
  
  if(il == NULL)
    return NO_ERROR;

  if(vl == NULL){
    report_error(__FILE__, __LINE__, ERROR_INVALID_ARGUMENT, 1);
    return ERROR_INVALID_ARGUMENT;
  }

  /* Add time relations to variables. */
  initlist = LIST_ITERATOR(il);
  while(initlist != NULL){
    v1 = initlist->var;
    v2 = get_parser_variable(vl, initlist->next);
    if(v1->cardinality == v2->cardinality){
      /* check one thing */
      for(i = 0; i < v1->cardinality; i++){
	if(strcmp(get_statename(v1, i), get_statename(v2, i))){
	  fprintf(stderr, 
		  "Warning: Corresponding variables %s and %s\n", 
		  get_symbol(v1), get_symbol(v2));
	  fprintf(stderr, 
		  "have different kind of states %s and %s!\n", 
		  get_statename(v1,i), get_statename(v2,i));
	}
      }
      /* the core */
      v2->next = v1;     /* v2 belongs to V(t)   */
      v1->previous = v2; /* v1 belongs to V(t-1) */
    }
    else{
      fprintf(stderr, 
	      "NET parser: Invalid 'NIP_next' field for node %s!\n",
	      get_symbol(v1));
      report_error(__FILE__, __LINE__, ERROR_GENERAL, 1);
      return ERROR_GENERAL;
    }
    initlist = initlist->fwd;
  }

  /* Find out which variables belong to incoming/outgoing interfaces */
  it = LIST_ITERATOR(vl);
  v2 = next_variable(&it); /* get a variable */
  while(v2 != NULL){
    m = 0;

    for(i = 0; i < v2->num_of_parents; i++){ /* for each parent */
      v1 = v2->parents[i];

      /* Condition for belonging to the incoming interface */
      if(v1->previous != NULL && 
	 v2->previous == NULL){ 
	/* v2 has the parent v1 in the previous time slice */
	v1->if_status |= INTERFACE_OLD_OUTGOING;
	v1->previous->if_status |= INTERFACE_OUTGOING;
	v2->if_status |= INTERFACE_INCOMING;
	m = 1;
	/* break; ?? */

#ifdef DEBUG_BISON
	fprintf(stdout, 
	      "NET parser: Node %s in I_{t}->\n",
	      get_symbol(v1->previous));
	fprintf(stdout, 
	      "NET parser: Node %s in I_{t-1}->\n",
	      get_symbol(v1));
	fprintf(stdout, 
	      "NET parser: Node %s in I_{t}<-\n",
	      get_symbol(v2));
#endif
      }
    }
    if(m){ /* parents of v2 in this time slice belong to incoming interface */
      for(i = 0; i < v2->num_of_parents; i++){
	v1 = v2->parents[i];
	if(v1->previous == NULL){ 
	  /* v1 (in time slice t) is married with someone in t-1 */
	  v1->if_status |= INTERFACE_INCOMING;

#ifdef DEBUG_BISON
	fprintf(stdout, 
	      "NET parser: Node %s in I_{t}<-\n",
	      get_symbol(v1));
#endif
	}
      }
    }
    v2 = next_variable(&it);
  }
  return NO_ERROR;
}


static void print_parsed_stuff(potentialList pl){
  int i, j;
  unsigned long temp;
  potentialLink list = pl->first;

  /* Traverse through the list of parsed potentials. */
  while(list != NULL){
    int *indices; 
    int *temp_array;
    variable *variables;

    if((indices = (int *) calloc(list->data->num_of_vars,
				 sizeof(int))) == NULL){
      report_error(__FILE__, __LINE__, ERROR_OUTOFMEMORY, 1);
      return;
    }

    if((temp_array = (int *) calloc(list->data->num_of_vars,
				    sizeof(int))) == NULL){
      report_error(__FILE__, __LINE__, ERROR_OUTOFMEMORY, 1);
      free(indices);
      return;
    }

    if((variables = (variable *) calloc(list->data->num_of_vars,
					sizeof(variable))) == NULL){
      report_error(__FILE__, __LINE__, ERROR_OUTOFMEMORY, 1);
      free(indices);
      free(temp_array);
      return;
    }
    
    variables[0] = list->child;
    for(i = 1; i < list->data->num_of_vars; i++)
      variables[i] = (list->parents)[i - 1];

    /* reorder[i] is the place of i:th variable (in the sense of this program) 
     * in the array variables[] */
    
    /* init (needed?) */
    for(i = 0; i < list->data->num_of_vars; i++)
      temp_array[i] = 0;
    
    /* Create the reordering table: O(num_of_vars^2) i.e. stupid but working.
     * Note the temporary use of indices array. */
    for(i = 0; i < list->data->num_of_vars; i++){
      temp = get_id(variables[i]);
      for(j = 0; j < list->data->num_of_vars; j++){
	if(get_id(variables[j]) > temp)
	  temp_array[j]++; /* counts how many greater variables there are */
      }
    }
    
    /* Go through every number in the potential array. */
    for(i = 0; i < list->data->size_of_data; i++){
      
      inverse_mapping(list->data, i, indices);

      printf("P( %s = %s", list->child->symbol, 
	     (list->child->statenames)[indices[temp_array[0]]]);

      if(list->data->num_of_vars > 1)
	printf(" |");

      for(j = 0; j < list->data->num_of_vars - 1; j++)
	printf(" %s = %s", ((list->parents)[j])->symbol,
	       (((list->parents)[j])->statenames)[indices[temp_array[j + 1]]]);
      
      printf(" ) = %.2f \n", (list->data->data)[i]);
    }
    list = list->fwd;
    
    free(indices);
    free(temp_array);
    free(variables);
  }
}


FILE *open_net_file(const char *filename){
  if(!nip_net_file_open){
    nip_net_file = fopen(filename,"r");
    if (!nip_net_file){
      report_error(__FILE__, __LINE__, ERROR_IO, 1);
      return NULL; /* fopen(...) failed */
    }
    else{
      nip_net_file_open = 1;
      /* nip_read_line = 1; Was this necessary? JJT 5.1.2007 */
    }
  }
  return nip_net_file;
}


void close_net_file(){
  if(nip_net_file_open){
    fclose(nip_net_file);
    nip_net_file_open = 0;
  }
}


/* Gives you the list of variables after yyparse() */
variablelist get_parsed_variables (void){
  return nip_parsed_vars;
}


/* Gives you the array of cliques after yyparse() */
int get_cliques (clique** clique_array_pointer){
  *clique_array_pointer = nip_cliques;
  return nip_n_cliques;
}


void get_parsed_node_size(int* x, int* y){
  *x = nip_node_size_x;
  *y = nip_node_size_y;
}

