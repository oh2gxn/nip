%
% NIPEXPERIMENT( )
% 
% Matlab script for experimenting with the effects of computing 
% Bayes network inference results while varying the floating point 
% precision used in the arithmetics.
%

% constants
newSignals = 1; % 0 == signals already generated
newResults = 1; % 0 == don't compute the stuff again
doItInC = 1;    % 0 == do it in Matlab instead of C
N = 100; % number of experiment iterations
T = 128; % time series length
digits = [1,2,3,4,5,6,7,8,9,10]; % used FP precisions
Ndigits = length(digits);
datapath = '/share/pattern/ismo/float/data'; % store data somewhere else
model = sprintf('%s/origModel.net', datapath); % source of artificial data

% initialize the random number generator
RandStream.setDefaultStream(RandStream('mt19937ar', 'seed', 42));

% Create the data set
fileIn = sprintf('%s/timeseries.txt', datapath, n); % filename
if (newSignals)
  % create the signal: sampled from a known model
  cmd = sprintf('!./util/gen_test %s %d %d %s', model, N, T, fileIn);
  eval(cmd);
end

% TODO: Compute some results?
for k = 1:Ndigits
  % number of digits used in the computation
  d = digits(k);
  
  variable = 'TODO';
  fileOut = sprintf('%s/inference-%s-%d.txt', datapath, variable, d);
  if (newResults)
    erase = sprintf('!rm %s', fileOut); % erase old results
    eval(erase);
    
    if (doItInC)
      % run inference
      cmd = sprintf('!./util/inftest %s %s %s %s', ...
		    model, fileIn, variable, fileOut);
      eval(cmd);
    else
      % Matlab implementation
      input = load(fileIn, '-ascii');
      output = 1; % TODO?
      cmd = sprintf('!echo "%g" >> %s', output, fileOut); 
      eval(cmd);
    end
  end

  % TODO read the results from fileOut?
  
  % clean up useless variables
  clear('cmd', 'fileIn', 'fileOut');
end


% Visualize results
fh = figure('Name','Join tree inference vs. arithmetic precision');
hold on;
set(gca, 'xTick', digits);
% TODO: plot something interesting
plot(digits, ones(size(digits)), 'b:'); % the accurate value for monitored
plot(digits, zeros(size(digits)), 'm:'); % the accurate value for neighbor
axis([digits(1), digits(end), -0.2, 1.2]);
%legend({sprintf('%g Hz bin',mFM), sprintf('%g Hz bin',mFN)}, ...
%       'Location', 'Best');
xlabel('digits');
ylabel('computed result');
title('Join tree inference vs. arithmetic precision');
print('-depsc2', '/share/pattern/ismo/float/doc/nip.eps');


