#include <stdlib.h>
#include <stdio.h>
#include "Graph.h"
#include "Variable.h"

void main() {

    Graph *G;
    Variable v1, v2, v3;

    /* XX fundeeraa detaileja */

}
