/*
 * nip.h $Id$
 */

#ifndef __NIP_H__
#define __NIP_H__

#include "Clique.h"
#include "Variable.h"

struct nip {
  Clique *cliques;

};

#endif /* __NIP_H__ */
